import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Import page components
import CreateRuleDashboard from './pages/CreateRuleDashboard';
import ActiveRuleDashboard from './pages/active-rule-dashboard';

const AppRoutes = () => {
  return (
    <Router>
      <Routes>
        <Route path="/rules" element={<CreateRuleDashboard />} />
        <Route path="/active-rule-dashboard" element={<ActiveRuleDashboard />} />
        <Route path="/" element={<ActiveRuleDashboard />} />
      </Routes>
    </Router>
  );
};

export default AppRoutes;