import React from 'react';
import { InfoSectionProps } from '../../types/CreateRuleDashboard';

const InfoSection: React.FC<InfoSectionProps> = ({
  title = "WHAT ARE CAMPAIGN RULES ?",
  description = "Campaign rules are automated checks that help automate errors , optimize performance , and ensure campaigns are running to best practices and business requirements."
}) => {
  return (
    <div className="bg-purple-50 rounded-2xl p-8 shadow-lg">
      <div className="bg-purple-200 rounded-2xl px-6 py-3 mb-6 inline-block">
        <h3 className="text-purple-900 font-medium text-lg">{title}</h3>
      </div>
      <p className="text-purple-900 text-sm leading-relaxed max-w-4xl">
        {description}
      </p>
    </div>
  );
};

export default InfoSection;