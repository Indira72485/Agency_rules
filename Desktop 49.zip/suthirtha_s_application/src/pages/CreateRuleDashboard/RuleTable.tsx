import React from 'react';
import Button from '../../components/ui/Button';
import { RuleTableProps } from '../../types/CreateRuleDashboard';

const RuleTable: React.FC<RuleTableProps> = ({ rules, onEdit, onAdd }) => {
  const getSeverityColor = (severity: string) => {
    return severity === 'High' ? 'bg-red-200 text-red-600' : 'bg-green-200 text-green-700';
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      {/* Table Header */}
      <div className="bg-purple-600 bg-opacity-90 px-6 py-4">
        <div className="grid grid-cols-7 gap-4 items-center">
          <div className="text-white font-semibold text-xl">Rules</div>
          <div className="text-white font-bold text-xl">Type</div>
          <div className="text-white font-bold text-xl">Severity</div>
          <div className="text-black font-light text-xl">Account ID</div>
          <div className="text-black font-light text-xl">Category</div>
          <div className="text-white font-bold text-xl">Edit</div>
          <div className="text-white font-bold text-xl flex items-center justify-between">
            Action
            <button className="ml-2">
              <img src="/images/img_icbaselineplus.svg" alt="Add" className="w-11 h-11" />
            </button>
          </div>
        </div>
      </div>

      {/* Table Body */}
      <div className="divide-y divide-purple-400 divide-opacity-60">
        {rules.map((rule, index) => (
          <div key={rule.id} className="px-6 py-4">
            <div className="grid grid-cols-7 gap-4 items-center">
              <div className="text-purple-900 font-semibold text-xl">{rule.name}</div>
              
              <div>
                <span className="bg-white text-purple-900 px-6 py-2 rounded-xl border border-purple-400 border-opacity-40 font-semibold shadow-md">
                  {rule.type}
                </span>
              </div>
              
              <div>
                <span className={`px-5 py-2 rounded-xl font-semibold shadow-md ${getSeverityColor(rule.severity)}`}>
                  {rule.severity}
                </span>
              </div>
              
              <div>
                <span className="bg-purple-100 text-black px-5 py-2 rounded-2xl font-medium shadow-md">
                  {rule.accountId}
                </span>
              </div>
              
              <div className="text-purple-900 font-normal">{rule.category}</div>
              
              <div>
                <Button 
                  variant="edit" 
                  size="sm"
                  onClick={() => onEdit(rule.id)}
                  className="px-6 py-2 rounded-lg shadow-md"
                >
                  EDIT
                </Button>
              </div>
              
              <div>
                <Button 
                  variant="add" 
                  size="sm"
                  onClick={() => onAdd(rule.id)}
                  className="px-5 py-2 rounded-lg shadow-sm"
                >
                  ADD
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RuleTable;