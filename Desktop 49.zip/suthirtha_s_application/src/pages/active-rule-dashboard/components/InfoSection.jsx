// src/pages/active-rule-dashboard/components/InfoSection.jsx
import React from 'react';

const InfoSection = ({ title, description }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-semibold text-purple-900 mb-4">
        {title || "Rule Information"}
      </h2>
      <p className="text-gray-700">
        {description || "This section provides additional information about your active rules and their performance metrics."}
      </p>
    </div>
  );
};

export default InfoSection;