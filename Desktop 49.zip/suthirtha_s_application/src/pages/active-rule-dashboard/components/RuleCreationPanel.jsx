// src/pages/active-rule-dashboard/components/RuleCreationPanel.jsx
import React, { useState } from 'react';
import Button from '../../../components/ui/Button';
import Dropdown from '../../../components/ui/Dropdown';

const RuleCreationPanel = ({ onClose, onSave }) => {
  const [ruleData, setRuleData] = useState({
    name: '',
    type: '',
    severity: '',
    accountId: '',
    category: '',
    condition: '',
    threshold: '',
    action: ''
  });

  const [errors, setErrors] = useState({});

  const ruleTypes = [
    { value: 'Budget', label: 'Budget' },
    { value: 'Performance', label: 'Performance' },
    { value: 'Audience', label: 'Audience' },
    { value: 'Engagement', label: 'Engagement' }
  ];

  const severityOptions = [
    { value: 'High', label: 'High' },
    { value: 'Low', label: 'Low' },
    { value: 'Medium', label: 'Medium' }
  ];

  const categoryOptions = [
    { value: 'AI-Generated', label: 'AI-Generated' },
    { value: 'ADMIN', label: 'ADMIN' },
    { value: 'Custom', label: 'Custom' }
  ];

  const conditionOptions = [
    { value: 'greater_than', label: 'Greater than' },
    { value: 'less_than', label: 'Less than' },
    { value: 'equals', label: 'Equals' },
    { value: 'between', label: 'Between' }
  ];

  const actionOptions = [
    { value: 'pause_campaign', label: 'Pause Campaign' },
    { value: 'increase_budget', label: 'Increase Budget' },
    { value: 'decrease_budget', label: 'Decrease Budget' },
    { value: 'send_notification', label: 'Send Notification' }
  ];

  const handleInputChange = (field, value) => {
    setRuleData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!ruleData.name.trim()) newErrors.name = 'Rule name is required';
    if (!ruleData.type) newErrors.type = 'Rule type is required';
    if (!ruleData.severity) newErrors.severity = 'Severity is required';
    if (!ruleData.accountId.trim()) newErrors.accountId = 'Account ID is required';
    if (!ruleData.category) newErrors.category = 'Category is required';
    if (!ruleData.condition) newErrors.condition = 'Condition is required';
    if (!ruleData.threshold.trim()) newErrors.threshold = 'Threshold is required';
    if (!ruleData.action) newErrors.action = 'Action is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (validateForm()) {
      onSave(ruleData);
    }
  };

  const handleSaveDraft = () => {
    console.log('Saving draft:', ruleData);
    // Add draft saving logic here
  };

  const handleTestRule = () => {
    console.log('Testing rule:', ruleData);
    // Add rule testing logic here
  };

  return (
    <div className="bg-white rounded-lg shadow-xl border-2 border-purple-200 overflow-hidden animate-in slide-in-from-top duration-300">
      {/* Panel Header */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-white">Create New Rule</h2>
          <button 
            onClick={onClose}
            className="text-white hover:text-purple-200 transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>

      {/* Panel Content */}
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left Column - Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-purple-900 mb-4">Basic Information</h3>
            
            {/* Rule Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Rule Name</label>
              <input
                type="text"
                value={ruleData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                  errors.name ? 'border-red-500' : 'border-gray-300'
                }`}
                placeholder="Enter rule name"
              />
              {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
            </div>

            {/* Rule Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Rule Type</label>
              <Dropdown
                options={ruleTypes}
                value={ruleData.type}
                onChange={(value) => handleInputChange('type', value)}
                placeholder="Select rule type"
                error={errors.type}
              />
              {errors.type && <p className="text-red-500 text-sm mt-1">{errors.type}</p>}
            </div>

            {/* Severity */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Severity</label>
              <Dropdown
                options={severityOptions}
                value={ruleData.severity}
                onChange={(value) => handleInputChange('severity', value)}
                placeholder="Select severity"
                error={errors.severity}
              />
              {errors.severity && <p className="text-red-500 text-sm mt-1">{errors.severity}</p>}
            </div>

            {/* Account ID */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Account ID</label>
              <input
                type="text"
                value={ruleData.accountId}
                onChange={(e) => handleInputChange('accountId', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                  errors.accountId ? 'border-red-500' : 'border-gray-300'
                }`}
                placeholder="Enter account ID"
              />
              {errors.accountId && <p className="text-red-500 text-sm mt-1">{errors.accountId}</p>}
            </div>

            {/* Category */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
              <Dropdown
                options={categoryOptions}
                value={ruleData.category}
                onChange={(value) => handleInputChange('category', value)}
                placeholder="Select category"
                error={errors.category}
              />
              {errors.category && <p className="text-red-500 text-sm mt-1">{errors.category}</p>}
            </div>
          </div>

          {/* Right Column - Rule Parameters */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-purple-900 mb-4">Rule Parameters</h3>
            
            {/* Condition */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Condition</label>
              <Dropdown
                options={conditionOptions}
                value={ruleData.condition}
                onChange={(value) => handleInputChange('condition', value)}
                placeholder="Select condition"
                error={errors.condition}
              />
              {errors.condition && <p className="text-red-500 text-sm mt-1">{errors.condition}</p>}
            </div>

            {/* Threshold */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Threshold Value</label>
              <input
                type="number"
                value={ruleData.threshold}
                onChange={(e) => handleInputChange('threshold', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                  errors.threshold ? 'border-red-500' : 'border-gray-300'
                }`}
                placeholder="Enter threshold value"
              />
              {errors.threshold && <p className="text-red-500 text-sm mt-1">{errors.threshold}</p>}
            </div>

            {/* Action */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Action</label>
              <Dropdown
                options={actionOptions}
                value={ruleData.action}
                onChange={(value) => handleInputChange('action', value)}
                placeholder="Select action"
                error={errors.action}
              />
              {errors.action && <p className="text-red-500 text-sm mt-1">{errors.action}</p>}
            </div>

            {/* Rule Preview */}
            <div className="bg-purple-50 p-4 rounded-lg">
              <h4 className="text-sm font-semibold text-purple-900 mb-2">Rule Preview</h4>
              <p className="text-sm text-gray-700">
                {ruleData.name || 'Rule Name'}: When {ruleData.type || 'metric'} is {ruleData.condition || 'condition'} {ruleData.threshold || 'threshold'}, then {ruleData.action || 'action'}.
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
          <div className="flex space-x-3">
            <Button
              variant="outline"
              size="md"
              onClick={handleSaveDraft}
              className="px-6 py-2"
            >
              Save Draft
            </Button>
            <Button
              variant="outline"
              size="md"
              onClick={handleTestRule}
              className="px-6 py-2"
            >
              Test Rule
            </Button>
          </div>
          
          <div className="flex space-x-3">
            <Button
              variant="outline"
              size="md"
              onClick={onClose}
              className="px-6 py-2"
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              size="md"
              onClick={handleSave}
              className="px-8 py-2 bg-purple-600 hover:bg-purple-700 text-white"
            >
              Create & Activate
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RuleCreationPanel;