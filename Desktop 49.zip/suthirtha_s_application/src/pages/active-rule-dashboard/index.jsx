// src/pages/active-rule-dashboard/index.jsx
import React, { useState } from 'react';
import Header from '../../components/common/Header';
import Sidebar from '../../components/common/Sidebar';
import Button from '../../components/ui/Button';
import RuleTable from './components/RuleTable';
import InfoSection from './components/InfoSection';
import RuleCreationPanel from './components/RuleCreationPanel';

const ActiveRuleDashboard = () => {
  const [activeMenuItem, setActiveMenuItem] = useState('dashboard');
  const [isCreationPanelOpen, setIsCreationPanelOpen] = useState(false);

  // Sample rules data
  const [rules, setRules] = useState([
    {
      id: '1',
      name: 'Budget Threshold',
      type: 'Budget',
      severity: 'High',
      accountId: 'ABC123',
      category: 'AI-Generated'
    },
    {
      id: '2',
      name: 'Conversion Rate',
      type: 'Performance',
      severity: 'Low',
      accountId: 'XYZ345',
      category: 'AI-Generated'
    },
    {
      id: '3',
      name: 'Audience Reach',
      type: 'Audience',
      severity: 'High',
      accountId: 'Tyojj1345',
      category: 'ADMIN'
    },
    {
      id: '4',
      name: 'Budget Threshold',
      type: 'Budget',
      severity: 'High',
      accountId: 'ABC123',
      category: 'AI-Generated'
    },
    {
      id: '5',
      name: 'Conversion Rate',
      type: 'Performance',
      severity: 'Low',
      accountId: 'XYZ345',
      category: 'AI-Generated'
    },
    {
      id: '6',
      name: 'Audience Reach',
      type: 'Audience',
      severity: 'High',
      accountId: 'Tyojj1345',
      category: 'ADMIN'
    },
    {
      id: '7',
      name: 'Budget Threshold',
      type: 'Budget',
      severity: 'High',
      accountId: 'ABC123',
      category: 'AI-Generated'
    },
    {
      id: '8',
      name: 'Conversion Rate',
      type: 'Performance',
      severity: 'Low',
      accountId: 'XYZ345',
      category: 'AI-Generated'
    },
    {
      id: '9',
      name: 'Audience Reach',
      type: 'Audience',
      severity: 'High',
      accountId: 'Tyojj1345',
      category: 'ADMIN'
    }
  ]);

  const handleBackToRules = () => {
    console.log('Navigating back to rules');
    // Add navigation logic here
  };

  const handleMenuItemClick = (item) => {
    setActiveMenuItem(item);
    console.log(`Menu item clicked: ${item}`);
  };

  const handleEditRule = (ruleId) => {
    console.log(`Editing rule: ${ruleId}`);
    // Add edit logic here
  };

  const handleAddRule = (ruleId) => {
    console.log(`Adding rule: ${ruleId}`);
    // Add rule logic here
  };

  const handleSettingsClick = () => {
    console.log('Settings clicked');
  };

  const handleNotificationClick = () => {
    console.log('Notification clicked');
  };

  const handleCreateRuleClick = () => {
    setIsCreationPanelOpen(true);
  };

  const handleCloseCreationPanel = () => {
    setIsCreationPanelOpen(false);
  };

  const handleSaveRule = (newRule) => {
    const ruleWithId = {
      ...newRule,
      id: (rules.length + 1).toString()
    };
    setRules([...rules, ruleWithId]);
    setIsCreationPanelOpen(false);
    console.log('Rule saved:', ruleWithId);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-200 via-gray-100 to-pink-100">
      {/* Sidebar */}
      <Sidebar 
        activeItem={activeMenuItem}
        onItemClick={handleMenuItemClick}
      />

      {/* Main Content */}
      <div className="ml-24">
        {/* Header */}
        <Header 
          title="Active Rule"
          username="Campaignion 2025"
          onSettingsClick={handleSettingsClick}
          onNotificationClick={handleNotificationClick}
        />

        {/* Content Area */}
        <div className="px-6 py-6">
          {/* Back to Rules Button */}
          <div className="mb-6">
            <Button
              variant="outline"
              size="md"
              onClick={handleBackToRules}
              className="bg-white bg-opacity-50 shadow-md rounded-lg px-6 py-3 flex items-center space-x-3"
            >
              <img src="/images/img_mask_group.svg" alt="Back" className="w-5 h-5" />
              <span className="text-purple-900 font-semibold text-2xl">Back to Rules</span>
            </Button>
          </div>

          {/* Rule Creation Panel */}
          {isCreationPanelOpen && (
            <div className="mb-8">
              <RuleCreationPanel 
                onClose={handleCloseCreationPanel}
                onSave={handleSaveRule}
              />
            </div>
          )}

          {/* Rules Table */}
          <div className="mb-8">
            <RuleTable 
              rules={rules}
              onEdit={handleEditRule}
              onAdd={handleAddRule}
              onCreateRule={handleCreateRuleClick}
            />
          </div>

          {/* Info Section */}
          <InfoSection />
        </div>
      </div>

      {/* Chat Widget */}
      <div className="fixed bottom-6 right-6">
        <button className="bg-purple-900 rounded-full p-4 shadow-lg hover:bg-purple-800 transition-colors">
          <img src="/images/img_vector_purple_900.svg" alt="Chat" className="w-19 h-19" />
        </button>
      </div>
    </div>
  );
};

export default ActiveRuleDashboard;