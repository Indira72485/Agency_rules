export interface Rule {
  id: string;
  name: string;
  type: string;
  severity: 'High' | 'Low';
  accountId: string;
  category: string;
}

export interface RuleTableProps {
  rules: Rule[];
  onEdit: (ruleId: string) => void;
  onAdd: (ruleId: string) => void;
}

export interface InfoSectionProps {
  title?: string;
  description?: string;
}