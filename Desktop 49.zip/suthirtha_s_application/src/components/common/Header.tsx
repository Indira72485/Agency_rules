import React from 'react';

interface HeaderProps {
  title?: string;
  username?: string;
  onSettingsClick?: () => void;
  onNotificationClick?: () => void;
}

const Header: React.FC<HeaderProps> = ({
  title = "Create Rule",
  username = "Campaignion 2025",
  onSettingsClick = () => console.log('Settings clicked'),
  onNotificationClick = () => console.log('Notification clicked')
}) => {
  return (
    <header className="w-full bg-gradient-to-r from-purple-200 via-gray-100 to-pink-100 px-6 py-4">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <button className="p-2">
            <img src="/images/img_bxarrowback.svg" alt="Back" className="w-9 h-9" />
          </button>
          <h1 className="text-5xl font-light text-purple-900">{title}</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          <span className="text-purple-700 font-semibold">@ {username}</span>
          <button onClick={onSettingsClick} className="p-2">
            <img src="/images/img_materialsymbolssettingsoutlinerounded_purple_900.svg" alt="Settings" className="w-9 h-9" />
          </button>
          <button onClick={onNotificationClick} className="p-2">
            <img src="/images/img_mingcutenotificationfill.svg" alt="Notifications" className="w-9 h-9" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;