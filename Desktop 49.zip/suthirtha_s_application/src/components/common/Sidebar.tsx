import React from 'react';

interface SidebarProps {
  activeItem?: string;
  onItemClick?: (item: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  activeItem = 'dashboard',
  onItemClick = () => {}
}) => {
  const menuItems = [
    { id: 'profile', icon: '/images/img_vector_white_a700_50x58.svg', label: 'Profile' },
    { id: 'dashboard', icon: '/images/img_fluentmdl2bidashboard.svg', label: 'Dashboard' },
    { id: 'analytics', icon: '/images/img_vector.svg', label: 'Analytics' },
    { id: 'reports', icon: '/images/img_vector_white_a700.svg', label: 'Reports' },
    { id: 'campaigns', icon: '/images/img_vector_white_a700_39x39.svg', label: 'Campaigns' },
    { id: 'insurance', icon: '/images/img_mapinsuranceagency.svg', label: 'Insurance' },
    { id: 'community', icon: '/images/img_ricommunityfill.svg', label: 'Community' },
    { id: 'users', icon: '/images/img_mageusersfill.svg', label: 'Users' },
    { id: 'settings', icon: '/images/img_materialsymbolssettingsoutlinerounded.svg', label: 'Settings' },
    { id: 'logout', icon: '/images/img_vector_white_a700_46x46.svg', label: 'Logout' }
  ];

  return (
    <aside className="fixed left-0 top-0 h-full w-24 bg-purple-900 shadow-lg rounded-r-3xl z-10">
      <div className="flex flex-col items-center py-8 space-y-6">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onItemClick(item.id)}
            className={`p-3 rounded-full transition-colors duration-200 ${
              activeItem === item.id ? 'bg-purple-700' : 'hover:bg-purple-800'
            }`}
            title={item.label}
          >
            <img 
              src={item.icon} 
              alt={item.label} 
              className="w-10 h-10 filter brightness-0 invert"
            />
          </button>
        ))}
      </div>
    </aside>
  );
};

export default Sidebar;