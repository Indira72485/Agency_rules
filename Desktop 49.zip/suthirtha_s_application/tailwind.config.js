/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          light: '#4da6ff',
          DEFAULT: '#0078ff',
          dark: '#0057b8',
        },
        purple: {
          50: '#faf6fd',
          100: '#f3e2ff',
          200: '#d4cbfc',
          600: '#9036ff',
          700: '#721aa9',
          800: '#6e09af',
          900: '#4d166f',
        },
        gray: {
          100: '#f0efef',
        },
        pink: {
          100: '#f7dceb',
        },
        red: {
          200: '#ffcdcd',
          600: '#ff6262',
        },
        green: {
          200: '#e9ffa3',
          700: '#3f9704',
        },
        blue: {
          600: '#0c00f6',
          700: '#1500ff',
        }
      },
      backgroundImage: {
        'gradient-main': 'linear-gradient(141deg, #d4cbfc 0%, #f0efef 50%, #f7dceb 100%)',
      },
      boxShadow: {
        'custom-light': '0px 4px 4px #ffffff4c',
        'custom-dark': '0px 4px 4px #0000002c',
        'custom-black': '0px 4px 4px #0c0c0c3f',
        'custom-gray': '0px 4px 4px #0000008c',
        'custom-subtle': '0px 4px 4px #00000019',
        'custom-info': '0px 4px 4px #00000059',
      },
      spacing: {
        '19': '4.75rem',
      }
    },
  },
  plugins: [],
}